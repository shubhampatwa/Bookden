package com.den.bookden;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.den.bookden.app.AppConfig;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Shubhi on 5/13/2016.
 */
public class BookDetailActivity extends AppCompatActivity {

    private ProgressDialog pDialog;
    private RecyclerView recyclerView;
    private BooksAdapter mAdapter;
    private Toolbar toolbar;
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_DETAIL = "detail";
    private static final String TAG_TITLE = "title";
    private static final String TAG_AUTHOR = "author";
    private static final String TAG_PUBLICATION = "publication";
    private static final String TAG_PAGES = "pages";
    private static final String TAG_TYPE = "type";
    private static final String TAG_CATEGORY = "category";
    private static final String TAG_E_COMMERCE = "e_commerce_link";
    private static final String TAG_LANGUAGE = "language";
    private static final String TAG_SAMPLE="sample";
    private static final String TAG_COVER="cover";
    private TextView txtTitle,txtAuthor,txtPublication,txtPages,txtType,txtCategory,txtEcommerce,txtLanguage;
    private String title,author,publication,type,category,e_commerce,language,sample,cover;
    private Button samplebook,share;
    private int pages;
    // URL to get contacts JSON
    private static String url = AppConfig.URL_START;
    JSONArray books = null;
    private List<Book> bookList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookdetail);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(getSupportActionBar()!=null)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        txtTitle=(TextView)findViewById(R.id.title);
        txtAuthor=(TextView)findViewById(R.id.author);
        txtPublication=(TextView)findViewById(R.id.publication);
        txtPages=(TextView)findViewById(R.id.pages);
        txtType=(TextView)findViewById(R.id.type);
        txtCategory=(TextView)findViewById(R.id.category);
        txtLanguage=(TextView)findViewById(R.id.language);
        txtEcommerce=(TextView)findViewById(R.id.e_commerce);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String title = extras.getString("title");
            String author = extras.getString("author");
            // Toast.makeText(this, category + " " + type, Toast.LENGTH_LONG).show();
            url = AppConfig.URL_START;
            url += "getBooks.php?title=" + title + "&&author=" + author;
            //this.setTitle(category + " " + type);
        }
        new GetDetail().execute();
        txtTitle.setText("Title :"+title);
        txtAuthor.setText("Author :"+author);
        txtPublication.setText("Publication :"+publication);
        txtPages.setText("Pages :"+pages);
        txtType.setText("Title :"+type);
        txtCategory.setText("Title :"+category);
        txtLanguage.setText("Title :"+language);
        txtEcommerce.setText("Link :"+e_commerce);
        //txtTitle.setText("Title :"+title);

//        samplebook.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i=new Intent(BookDetailActivity.this,GetSample.class);
//                i.putExtra("link",sample);
//                startActivity(i);
//            }
//        });
//        share.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
//                sharingIntent.setType("text/plain");
//                String shareBody = "Here is the share content body";
//                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
//                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
//                startActivity(Intent.createChooser(sharingIntent, "Share via"));
//            }
//        });



    }
    private class GetDetail extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(BookDetailActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
//            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url, ServiceHandler.GET);

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    books = jsonObj.getJSONArray(TAG_DETAIL);

                    // looping through All Contacts
                    for (int i = 0; i < books.length(); i++) {
                        JSONObject c = books.getJSONObject(i);

                         title = c.getString(TAG_TITLE);
                         author = c.getString(TAG_AUTHOR);
                         publication = c.getString(TAG_PUBLICATION);
                         pages=c.getInt(TAG_PAGES);
                         type=c.getString(TAG_TYPE);
                         category=c.getString(TAG_CATEGORY);
                         e_commerce=c.getString(TAG_E_COMMERCE);
                        language=c.getString(TAG_LANGUAGE);
                         sample=c.getString(TAG_SAMPLE);
                         cover=c.getString(TAG_COVER);

                        //bookList.add(book);




                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(BookDetailActivity.this, "No Books Found", Toast.LENGTH_LONG).show();
                // Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();

            /**
             * Updating parsed JSON data into ListView
             * */
//            ListAdapter adapter = new SimpleAdapter(
//                    ShowBookList_Activity.this, bookList,
//                    R.layout.list_item, new String[] { TAG_TITLE, TAG_AUTHOR,
//                    TAG_PUBLICATION }, new int[] { R.id.title,
//                    R.id.author, R.id.publication });
//
//            setListAdapter(adapter);
        }

    }
}
