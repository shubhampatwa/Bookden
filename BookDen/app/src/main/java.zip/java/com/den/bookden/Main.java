package com.den.bookden;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.TextView;
import com.den.bookden.app.*;
import com.den.bookden.helper.*;

import java.util.HashMap;

public class Main extends AppCompatActivity implements FragmentDrawer.FragmentDrawerListener {

    private Toolbar mToolbar;
    private FragmentDrawer drawerFragment;
    private TextView txtName;
    private TextView txtEmail;
    private Button btnLogout;

    private SQLiteHandler db;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        drawerFragment = (FragmentDrawer)getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        drawerFragment.setUp(R.id.fragment_navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout), mToolbar);
        drawerFragment.setDrawerListener(this);

        onNavigationDrawerItemSelected(0);

        txtName = (TextView) findViewById(R.id.name);
        txtEmail = (TextView) findViewById(R.id.email);
        btnLogout = (Button) findViewById(R.id.btnLogout);

        // SqLite database handler
        db = new SQLiteHandler(getApplicationContext());

        // session manager
        session = new SessionManager(getApplicationContext());

        if (!session.isLoggedIn()) {
            logoutUser();
        }

        // Fetching user details from sqlite
        HashMap<String, String> user = db.getUserDetails();

        String name = user.get("name");
        String email = user.get("email");
        //Toast.makeText(getApplicationContext(),name+" "+email,Toast.LENGTH_LONG).show();
        // Displaying the user details on the screen
        txtName.setText(name);
        txtEmail.setText(email);

        // Logout button click event
        btnLogout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            logoutUser();

        }

        return super.onOptionsItemSelected(item);
    }
    /**
     * Logging out the user. Will set isLoggedIn flag to false in shared
     * preferences Clears the user data from sqlite users table
     * */
    private void logoutUser() {
        session.setLogin(false);

        db.deleteUsers();

        // Launching the login activity
        Intent intent = new Intent(Main.this, MainActivity.class);
        startActivity(intent);

        finish();
    }

    @Override
    public void onDrawerItemSelected(View view, int position) {
        onNavigationDrawerItemSelected(position);
    }



    public void onNavigationDrawerItemSelected(int position) {
        switch(position) {
            case 0:
                break;
            case 1:
                Intent i=new Intent(this,ShowBookList_Activity.class);
                i.putExtra("category","romance");
                i.putExtra("type","fiction");
                startActivity(i);
                break;
            case 2:
                Intent thriller=new Intent(this,ShowBookList_Activity.class);
                thriller.putExtra("category","thriller");
                thriller.putExtra("type","fiction");
                startActivity(thriller);
                break;
            case 3:
                Intent mystery=new Intent(this,ShowBookList_Activity.class);
                mystery.putExtra("category","mystery");
                mystery.putExtra("type","fiction");
                startActivity(mystery);
                break;
            case 4:
                Intent short_stories=new Intent(this,ShowBookList_Activity.class);
                short_stories.putExtra("category","short_stories");
                short_stories.putExtra("type","fiction");
                startActivity(short_stories);
                break;
            case 5:
                Intent fantasy=new Intent(this,ShowBookList_Activity.class);
                fantasy.putExtra("category","fantasy");
                fantasy.putExtra("type","fiction");
                startActivity(fantasy);
                break;
            case 6:
                Intent myth=new Intent(this,ShowBookList_Activity.class);
                myth.putExtra("category","myths_legends_and_sagas");
                myth.putExtra("type","fiction");
                startActivity(myth);
                break;
            case 7:
                Intent biography=new Intent(this,ShowBookList_Activity.class);
                biography.putExtra("category","biography");
                biography.putExtra("type","non-fiction");
                startActivity(biography);
                break;
            case 8:
                Intent auto=new Intent(this,ShowBookList_Activity.class);
                auto.putExtra("category","autobiography");
                auto.putExtra("type","non-fiction");
                startActivity(auto);
                break;
            case 9:
                Intent poem=new Intent(this,ShowBookList_Activity.class);
                poem.putExtra("category","Poems");
                poem.putExtra("type","non-fiction");
                startActivity(poem);
                break;

        }
    }
}
