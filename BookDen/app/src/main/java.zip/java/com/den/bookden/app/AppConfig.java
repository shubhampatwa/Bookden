package com.den.bookden.app;

/**
 * Created by Shubhi on 4/12/2016.
 */
public class AppConfig {
    public static String URL_START="http://10.0.0.10/bookden/";
    public static String URL_LOGIN=URL_START+"login.php";
    public static String URL_REGISTER=URL_START+"register.php";
}
