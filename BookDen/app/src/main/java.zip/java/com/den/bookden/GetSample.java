package com.den.bookden;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

import com.den.bookden.app.AppConfig;

/**
 * Created by Shubhi on 5/13/2016.
 */
public class GetSample extends AppCompatActivity {

    private static String url = AppConfig.URL_START;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getsample);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String link = extras.getString("link");
            url = AppConfig.URL_START;
            url += link;
            //this.setTitle(category + " " + type);
        }
        WebView webview = (WebView) findViewById(R.id.webView);
        webview.getSettings().setJavaScriptEnabled(true);
        //String pdf = "http://www.adobe.com/devnet/acrobat/pdfs/pdf_open_parameters.pdf";
        webview.loadUrl("http://drive.google.com/viewerng/viewer?embedded=true&url=" + url);

    }
}
